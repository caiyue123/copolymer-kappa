﻿import sys, os

def fit_line(xs, ys):
    n = len(xs)
    mx = sum(xs) / n
    my = sum(ys) / n
    sxy = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    sxx = sum((xs[i] - mx) ** 2 for i in range(n))
    return sxy / sxx, my - (sxy / sxx) * mx

def box_L(datafile):
    for line in open(datafile, errors='ignore'):
        p = line.split()
        if len(p) == 4 and p[2] == 'xlo' and p[3] == 'xhi':
            return float(p[1]) - float(p[0])
    return None

def is_num(x):
    try:
        float(x)
        return True
    except:
        return False

def extract_k(logf, prof, L):
    rows = []
    for line in open(logf, errors='ignore'):
        p = line.split()
        if len(p) >= 7 and all(is_num(x) for x in p[:7]):
            rows.append([float(x) for x in p[:7]])
    if not rows:
        return None
    d = rows
    nve = [r for r in d if r[0] >= 5000]
    if len(nve) < 2:
        return None
    drift = abs(nve[-1][4] - nve[0][4])
    A = L * L
    blocks = {}
    cur = None
    for line in open(prof, errors='ignore'):
        s = line.strip()
        if s.startswith('#') or not s:
            continue
        p = s.split()
        if len(p) == 3 and p[1] == '10':
            cur = int(p[0])
            blocks[cur] = []
        elif len(p) == 4 and cur is not None:
            blocks[cur].append((float(p[1]), float(p[3])))
    if not blocks:
        return None
    ts = max(blocks)
    zT = blocks[ts]
    f2 = d[-1][6]
    t = d[-1][0] * 0.005
    J = f2 / (2 * t * A)
    z1 = [a[0] * L for a in zT if 0.15 <= a[0] <= 0.45]
    T1 = [a[1] for a in zT if 0.15 <= a[0] <= 0.45]
    z2 = [a[0] * L for a in zT if 0.65 <= a[0] <= 0.95]
    T2 = [a[1] for a in zT if 0.65 <= a[0] <= 0.95]
    if len(z1) < 2 or len(z2) < 2:
        return None
    k1, b1 = fit_line(z1, T1)
    k2, b2 = fit_line(z2, T2)
    kappa = J / ((abs(k1) + abs(k2)) / 2)
    return kappa, drift

DATA = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data'))

def get(d, logn, profn, datan):
    logf = os.path.join(d, logn)
    prof = os.path.join(d, profn)
    dat = os.path.join(d, datan)
    if not (os.path.exists(logf) and os.path.exists(prof) and os.path.exists(dat)):
        return None
    L = box_L(dat)
    if L is None:
        return None
    return extract_k(logf, prof, L)

print('=== gapfill (eps_B=0.3 第3重复) ===')
for name in ['S4_r3', 'RND_r3']:
    r = get(os.path.join(DATA, 'gapfill', name), 'log.rnemd', 'profile.out', 'relaxed.data')
    if r:
        print(f"{name}: kappa={r[0]:.2f} drift={r[1]:.5f}")
    else:
        print(f"{name}: NOT FOUND")

print()
print('=== mass6 (eps_B=0.3 + m_B=2) ===')
for name in ['A.s43', 'B.s43']:
    d = os.path.join(DATA, 'mass6', 'runs', name)
    r = get(d, 'log.rnemd.lammps', f'profile.{name}.out', f'data.A.relaxed.{name[2:]}')
    if r is None:
        r = get(d, 'log.rnemd.lammps', f'profile.{name}.out', f'data.{name.split(chr(46))[0]}.relaxed.{name.split(chr(46))[1]}')
    if r:
        print(f"{name}: kappa={r[0]:.2f} drift={r[1]:.5f}")
    else:
        print(f"{name}: NOT FOUND - check data files")
        for f in os.listdir(d):
            print(f"  {f}")

