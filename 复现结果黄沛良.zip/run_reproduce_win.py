﻿import sys, os, statistics

def fit_line(xs, ys):
    """纯 Python 最小二乘线性拟合，返回 (slope, intercept)"""
    n = len(xs)
    mx = sum(xs) / n
    my = sum(ys) / n
    sxy = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    sxx = sum((xs[i] - mx) ** 2 for i in range(n))
    slope = sxy / sxx
    intercept = my - slope * mx
    return slope, intercept

def r2_score(xs, ys, slope, intercept):
    ss_res = sum((ys[i] - (slope * xs[i] + intercept)) ** 2 for i in range(len(xs)))
    my = sum(ys) / len(ys)
    ss_tot = sum((ys[i] - my) ** 2 for i in range(len(ys)))
    return 1 - ss_res / ss_tot

DATA = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data'))

def box_L(datafile):
    for line in open(datafile, errors='ignore'):
        p = line.split()
        if len(p) == 4 and p[2] == 'xlo' and p[3] == 'xhi':
            return float(p[1]) - float(p[0])
    return None

def is_num(x):
    try:
        float(x)
        return True
    except:
        return False

def extract_kappa_alt(logf, profile, L):
    rows = []
    for line in open(logf, errors='ignore'):
        p = line.split()
        if len(p) >= 7 and all(is_num(x) for x in p[:7]):
            rows.append([float(x) for x in p[:7]])
    d = rows
    nve = [r for r in d if r[0] >= 5000]
    drift = abs(nve[-1][4] - nve[0][4])
    A = L * L
    blocks = {}
    cur = None
    for line in open(profile):
        s = line.strip()
        if s.startswith('#') or not s:
            continue
        p = s.split()
        if len(p) == 3 and p[1] == '10':
            cur = int(p[0])
            blocks[cur] = []
        elif len(p) == 4 and cur is not None:
            blocks[cur].append((float(p[1]), float(p[3])))
    ts = max(blocks)
    zT = blocks[ts]
    f2 = d[-1][6]
    t = d[-1][0] * 0.005
    J = f2 / (2 * t * A)
    z1 = [a[0] * L for a in zT if 0.15 <= a[0] <= 0.45]
    T1 = [a[1] for a in zT if 0.15 <= a[0] <= 0.45]
    z2 = [a[0] * L for a in zT if 0.65 <= a[0] <= 0.95]
    T2 = [a[1] for a in zT if 0.65 <= a[0] <= 0.95]
    k1, b1 = fit_line(z1, T1)
    k2, b2 = fit_line(z2, T2)
    dTdz = (abs(k1) + abs(k2)) / 2
    kappa = J / dTdz
    R1 = r2_score(z1, T1, k1, b1)
    R2 = r2_score(z2, T2, k2, b2)
    return dict(kappa=float(kappa), R1=float(R1), R2=float(R2), drift=float(drift))

def extract_dir(d):
    logf = os.path.join(d, 'log.rnemd')
    prof = os.path.join(d, 'p.out')
    data = os.path.join(d, 'relaxed.data')
    if not (os.path.exists(logf) and os.path.exists(prof) and os.path.exists(data)):
        return None
    L = box_L(data)
    if L is None:
        return None
    return extract_kappa_alt(logf, prof, L)

import numpy as np
npz = np.load(os.path.join(DATA, 'd7_kappa.npz'), allow_pickle=True)
r1 = {k[2:]: float(v) for k, v in npz.items()}
seqs = ['S1','S2','S3','S4','S5','S6','RND','pureA','pureB']
print('=== D7 50zhu 27zu (kappa) ===')
print(f"{'seq':<7}{'r1':>8}{'r2':>8}{'r3':>8}{'mean':>8}{'std':>8}")
for s in seqs:
    vals = [r1[s]]
    for rep in ['r2','r3']:
        r = extract_dir(os.path.join(DATA, 'repeats2', f'{s}_{rep}'))
        if r:
            vals.append(r['kappa'])
    m = statistics.mean(vals)
    sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
    print(f"{s:<7}" + "".join(f"{v:>8.2f}" for v in vals) + f"{m:>8.2f}{sd:>8.2f}")

print()
print('=== 20zhu dongjie 3chongfu ===')
print(f"{'sys':<7}{'s43':>8}{'s44':>8}{'s45':>8}{'mean':>8}{'std':>8}")
for sysn in ['A','AB','B']:
    vals = []
    for seed in [43,44,45]:
        r = extract_dir(os.path.join(DATA, 'repeats_frozen', f'{sysn}.s{seed}'))
        vals.append(r['kappa'] if r else float('nan'))
    vv = [v for v in vals if v == v]
    m = statistics.mean(vv)
    sd = statistics.stdev(vv) if len(vv) > 1 else 0.0
    print(f"{sysn:<7}" + "".join(f"{v:>8.2f}" if v==v else f"{'--':>8}" for v in vals) + f"{m:>8.2f}{sd:>8.2f}")

