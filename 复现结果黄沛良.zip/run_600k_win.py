﻿import sys, os, statistics

def fit_line(xs, ys):
    n = len(xs)
    mx = sum(xs) / n
    my = sum(ys) / n
    sxy = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    sxx = sum((xs[i] - mx) ** 2 for i in range(n))
    slope = sxy / sxx
    intercept = my - slope * mx
    return slope, intercept

DATA = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data'))

def box_L(datafile):
    for line in open(datafile, errors='ignore'):
        p = line.split()
        if len(p) == 4 and p[2] == 'xlo' and p[3] == 'xhi':
            return float(p[1]) - float(p[0])
    return None

def is_num(x):
    try:
        float(x)
        return True
    except:
        return False

def extract_kappa_alt(logf, profile, L):
    rows = []
    for line in open(logf, errors='ignore'):
        p = line.split()
        if len(p) >= 7 and all(is_num(x) for x in p[:7]):
            rows.append([float(x) for x in p[:7]])
    d = rows
    nve = [r for r in d if r[0] >= 5000]
    drift = abs(nve[-1][4] - nve[0][4])
    A = L * L
    blocks = {}
    cur = None
    for line in open(profile):
        s = line.strip()
        if s.startswith('#') or not s:
            continue
        p = s.split()
        if len(p) == 3 and p[1] == '10':
            cur = int(p[0])
            blocks[cur] = []
        elif len(p) == 4 and cur is not None:
            blocks[cur].append((float(p[1]), float(p[3])))
    ts = max(blocks)
    zT = blocks[ts]
    f2 = d[-1][6]
    t = d[-1][0] * 0.005
    J = f2 / (2 * t * A)
    z1 = [a[0] * L for a in zT if 0.15 <= a[0] <= 0.45]
    T1 = [a[1] for a in zT if 0.15 <= a[0] <= 0.45]
    z2 = [a[0] * L for a in zT if 0.65 <= a[0] <= 0.95]
    T2 = [a[1] for a in zT if 0.65 <= a[0] <= 0.95]
    k1, b1 = fit_line(z1, T1)
    k2, b2 = fit_line(z2, T2)
    dTdz = (abs(k1) + abs(k2)) / 2
    kappa = J / dTdz
    return dict(kappa=float(kappa), drift=float(drift), last_step=d[-1][0])

def extract_dir(d):
    logf = os.path.join(d, 'log.rnemd')
    prof = os.path.join(d, 'p.out')
    data = os.path.join(d, 'relaxed.data')
    if not (os.path.exists(logf) and os.path.exists(prof) and os.path.exists(data)):
        return None
    L = box_L(data)
    if L is None:
        return None
    return extract_kappa_alt(logf, prof, L)

def extract_600k(sysn):
    vals = []
    infos = []
    for seed in [43,44,45]:
        d = os.path.join(DATA, 'repeats_frozen_600k', f'{sysn}.s{seed}')
        r = extract_all(d)
        if r:
            vals.append(r['kappa'])
            infos.append(r)
    return vals, infos

def extract_all(d):
    logf = os.path.join(d, 'log.rnemd')
    prof = os.path.join(d, 'p.out')
    data = os.path.join(d, 'relaxed.data')
    if os.path.exists(logf) and os.path.exists(prof) and os.path.exists(data):
        L = box_L(data)
        if L:
            return extract_kappa_alt(logf, prof, L)
    return None

import statistics
print('=== 20zhu dongjie 600k 3chongfu ===')
print(f"{'sys':<7}{'s43':>8}{'s44':>8}{'s45':>8}{'mean':>8}{'std':>8}")
for sysn in ['A','AB','B']:
    vals = []
    drifts = []
    for seed in [43,44,45]:
        d = os.path.join(DATA, 'repeats_frozen_600k', f'{sysn}.s{seed}')
        r = extract_dir(d)
        if r:
            vals.append(r['kappa'])
            drifts.append(r['drift'])
    print(f"{sysn:<7}" + "".join(f"{v:>8.2f}" for v in vals) + f"{statistics.mean(vals):>8.2f}{statistics.stdev(vals):>8.2f}")
    print(f"  drift: {' '.join(f'{x:.5f}' for x in drifts)}")
