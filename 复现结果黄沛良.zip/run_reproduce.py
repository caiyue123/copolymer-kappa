﻿import sys, os, statistics
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calc_kappa import extract_kappa

DATA = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data'))

def box_L(datafile):
    for line in open(datafile, errors='ignore'):
        p = line.split()
        if len(p) == 4 and p[2] == 'xlo' and p[3] == 'xhi':
            return float(p[1]) - float(p[0])
    return None

def extract_dir(d):
    logf = os.path.join(d, 'log.rnemd')
    prof = os.path.join(d, 'p.out')
    data = os.path.join(d, 'relaxed.data')
    if not (os.path.exists(logf) and os.path.exists(prof) and os.path.exists(data)):
        return None
    L = box_L(data)
    if L is None: return None
    return extract_kappa(logf, prof, L)

import numpy as np
npz = np.load(os.path.join(DATA, 'd7_kappa.npz'), allow_pickle=True)
r1 = {k[2:]: float(v) for k, v in npz.items()}
seqs = ['S1','S2','S3','S4','S5','S6','RND','pureA','pureB']
print('=== D7 50zhu 27zu (kappa, tiaobianjieceng) ===')
print(f"{'seq':<7}{'r1':>8}{'r2':>8}{'r3':>8}{'mean':>8}{'std':>8}")
for s in seqs:
    vals = [r1[s]]
    for rep in ['r2','r3']:
        r = extract_dir(os.path.join(DATA, 'repeats2', f'{s}_{rep}'))
        if r: vals.append(r['kappa'])
    m = statistics.mean(vals); sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
    print(f"{s:<7}" + "".join(f"{v:>8.2f}" for v in vals) + f"{m:>8.2f}{sd:>8.2f}")

print()
print('=== 20zhu dongjie 3chongfu ===')
print(f"{'sys':<7}{'s43':>8}{'s44':>8}{'s45':>8}{'mean':>8}{'std':>8}")
for sysn in ['A','AB','B']:
    vals = []
    for seed in [43,44,45]:
        r = extract_dir(os.path.join(DATA, 'repeats_frozen', f'{sysn}.s{seed}'))
        vals.append(r['kappa'] if r else float('nan'))
    vv = [v for v in vals if v == v]
    m = statistics.mean(vv); sd = statistics.stdev(vv) if len(vv) > 1 else 0.0
    print(f"{sysn:<7}" + "".join(f"{v:>8.2f}" if v==v else f"{'--':>8}" for v in vals) + f"{m:>8.2f}{sd:>8.2f}")
