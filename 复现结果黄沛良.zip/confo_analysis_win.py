﻿import numpy as np, os

def read_data(fn):
    lines = open(fn, errors='ignore').readlines()
    L = None
    for l in lines[:20]:
        p = l.split()
        if len(p) == 4 and p[2] == 'xlo':
            L = float(p[1]) - float(p[0])
    atoms = {}
    in_atoms = False
    for l in lines:
        if l.startswith('Atoms'):
            in_atoms = True
            continue
        if in_atoms:
            if l.startswith(('Velocities', 'Bonds', 'Angles', 'Dihedrals', 'Impropers')):
                break
            p = l.split()
            if len(p) >= 6 and l.strip():
                atoms[int(p[0])] = (int(p[1]), int(p[2]), float(p[3]), float(p[4]), float(p[5]))
    return atoms, L

def analyze(atoms, L):
    mols = {}
    for aid, (m, t, x, y, z) in atoms.items():
        mols.setdefault(m, []).append((aid, x, y, z))
    rgs, rees, vecs = [], [], []
    for m, chain in mols.items():
        chain.sort()
        pos = [[x, y, z] for _, x, y, z in chain]
        import numpy as npa
        pos = npa.array(pos, dtype=float)
        for k in range(1, len(pos)):
            dd = pos[k] - pos[k-1]
            pos[k] -= npa.round(dd / L) * L
        com = pos.mean(axis=0)
        rgs.append(npa.sqrt(((pos - com)**2).sum(axis=1).mean()))
        rees.append(npa.linalg.norm(pos[-1] - pos[0]))
        vecs.append(pos[-1] - pos[0])
    vecs = npa.array(vecs)
    nvec = vecs / npa.linalg.norm(vecs, axis=1, keepdims=True)
    P2 = npa.mean(1.5 * nvec[:, 2]**2 - 0.5)
    return npa.mean(rgs), npa.mean(rees), P2

import os
base = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'repeats2'))
seqs = ['S1','S2','S3','S4','S5','S6','RND','pureA','pureB']
print(f"{'seq':<7}{'Rg(r2)':>8}{'Rg(r3)':>8}{'Ree(r2)':>9}{'Ree(r3)':>9}{'P2(r2)':>8}{'P2(r3)':>8}")
for s in seqs:
    vals = {}
    for rep in ['r2', 'r3']:
        fn = os.path.join(base, f'{s}_{rep}', 'relaxed.data')
        if os.path.exists(fn):
            atoms, L = read_data(fn)
            vals[rep] = analyze(atoms, L)
    r2 = vals.get('r2', (None,)*3)
    r3 = vals.get('r3', (None,)*3)
    fmt = lambda v: f"{v:>8.2f}" if v is not None else f"{'--':>8}"
    print(f"{s:<7}{fmt(r2[0])}{fmt(r3[0])}{fmt(r2[1])}{fmt(r3[1])}{fmt(r2[2])}{fmt(r3[2])}")
