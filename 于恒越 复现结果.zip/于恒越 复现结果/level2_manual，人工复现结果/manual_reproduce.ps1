# ============================================================
# 级别 2 人工复现 - 自动版（可选，手动版见对话教程）
# 用法：  powershell -ExecutionPolicy Bypass -File manual_reproduce.ps1 -Seed 1
#        或（在 PowerShell 里）  .\manual_reproduce.ps1 -Seed 1
# 参数：
#   -Seed  构型随机种子（默认 1；跑 3 重复时用 1/2/3 各跑一次）
#   -Seq   序列串（默认 S1）
#   -Root  输出根目录（默认 d:\下载\复现包\level2_manual）
# ============================================================
param(
  [int]$Seed = 1,
  [string]$Seq = "AAAAABBBBBAAAABBBBAAAABBBBAAABBBAAAAABBBBBAAAABBBB",
  [string]$Root = "d:\下载\复现包\level2_manual"
)
$ErrorActionPreference = 'Stop'
$pkg  = 'd:\下载\复现包'
$lmp  = 'D:\LAMMPS 64-bit 4Jul2026-MSMPI\bin\lmp.exe'
$enc  = New-Object System.Text.UTF8Encoding($false)

Write-Host "==> [1/4] 生成初始构型（seed=$Seed）"
& py "$pkg\scripts\build_seq.py" $Seq 50 50 $Seed "$Root\data.S1.s$Seed.in"

$dir = "$Root\run_S1_s$Seed"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Copy-Item "$Root\data.S1.s$Seed.in" "$dir\data.in" -Force

Write-Host "==> [2/4] 平衡 NVT->NPT->NVT（约 16 秒）"
[System.IO.File]::WriteAllText("$dir\in.equil",
  (Get-Content "$pkg\templates\in.equil.alt50" -Raw)
    .Replace('read_data data.alt50','read_data data.in')
    .Replace('write_data relaxed.alt50','write_data relaxed.data'), $enc)
Push-Location $dir
& $lmp -in in.equil -log log.equil > equil.out 2>&1
Pop-Location
if (-not (Test-Path "$dir\relaxed.data")) { throw "平衡失败：未生成 relaxed.data" }
Write-Host "    relaxed.data OK，Dangerous builds: $((Get-Content "$dir\equil.out" | Select-String 'Dangerous builds').Count) 处=0"

Write-Host "==> [3/4] RNEMD 60 万步（约 13 分钟）"
[System.IO.File]::WriteAllText("$dir\in.rnemd",
  (Get-Content "$pkg\templates\in.rnemd.alt50" -Raw)
    .Replace('read_data relaxed.alt50','read_data relaxed.data')
    .Replace('file p.alt50.out','file p.out')
    .Replace('run 400000','run 600000'), $enc)
Push-Location $dir
& $lmp -in in.rnemd -log log.rnemd > rnemd.out 2>&1
Pop-Location
if (-not (Select-String -Path "$dir\rnemd.out" -Pattern 'Total wall time' -Quiet)) { throw "RNEMD 未正常完成" }

Write-Host "==> [4/4] 提取 κ 与构象"
& py "$pkg\level2\analyze_level2.py" $Root $dir
Write-Host "完成！结果目录：$dir"
