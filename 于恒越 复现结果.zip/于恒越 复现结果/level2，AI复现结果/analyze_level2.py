# -*- coding: utf-8 -*-
"""级别 2 复现结果分析：κ（跳边界层口径）+ 构象（Rg/端距/P2）
用法：py analyze_level2.py <level2根目录> [run_S1_s1 run_S1_s2 ...]
"""
import sys, os, glob
import numpy as np

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
RUNS = sys.argv[2:] or sorted(glob.glob(os.path.join(ROOT, 'run_*')))
PKG = 'd:/下载/复现包'
sys.path.insert(0, os.path.join(PKG, 'scripts'))
from calc_kappa import extract_kappa


def box_L(datafile):
    for line in open(datafile, errors='ignore'):
        p = line.split()
        if len(p) == 4 and p[2] == 'xlo':
            return float(p[1]) - float(p[0])
    return None


def read_data(fn):
    lines = open(fn, errors='ignore').readlines()
    L = None
    for l in lines[:20]:
        p = l.split()
        if len(p) == 4 and p[2] == 'xlo':
            L = float(p[1]) - float(p[0])
    atoms = {}
    in_atoms = False
    for l in lines:
        if l.startswith('Atoms'):
            in_atoms = True
            continue
        if in_atoms:
            if l.startswith(('Velocities', 'Bonds', 'Angles', 'Dihedrals', 'Impropers')):
                break
            p = l.split()
            if len(p) >= 6 and l.strip():
                atoms[int(p[0])] = (int(p[1]), int(p[2]), float(p[3]), float(p[4]), float(p[5]))
    return atoms, L


def analyze_confo(atoms, L):
    mols = {}
    for aid, (m, t, x, y, z) in atoms.items():
        mols.setdefault(m, []).append((aid, x, y, z))
    rgs, rees, vecs = [], [], []
    for m, chain in mols.items():
        chain.sort()
        pos = np.array([[x, y, z] for _, x, y, z in chain])
        for k in range(1, len(pos)):
            d = pos[k] - pos[k-1]
            pos[k] -= np.round(d / L) * L
        com = pos.mean(axis=0)
        rgs.append(np.sqrt(((pos - com)**2).sum(axis=1).mean()))
        rees.append(np.linalg.norm(pos[-1] - pos[0]))
        vecs.append(pos[-1] - pos[0])
    vecs = np.array(vecs)
    nvec = vecs / np.linalg.norm(vecs, axis=1, keepdims=True)
    P2 = np.mean(1.5 * nvec[:, 2]**2 - 0.5)
    return np.mean(rgs), np.mean(rees), P2


print(f"{'run':<10}{'L':>8}{'last_step':>10}{'drift':>8}{'R2_1':>7}{'R2_2':>7}{'kappa':>8}  {'Rg':>6}{'Ree':>7}{'P2':>7}")
results = []
for r in RUNS:
    logf = os.path.join(r, 'log.rnemd')
    prof = os.path.join(r, 'p.out')
    data = os.path.join(r, 'relaxed.data')
    if not (os.path.exists(logf) and os.path.exists(prof) and os.path.exists(data)):
        print(f"{os.path.basename(r):<10}  (缺文件: log={os.path.exists(logf)} p={os.path.exists(prof)} data={os.path.exists(data)})")
        continue
    L = box_L(data)
    res = extract_kappa(logf, prof, L)
    atoms, L2 = read_data(data)
    rg, ree, p2 = analyze_confo(atoms, L2)
    print(f"{os.path.basename(r):<10}{L:>8.3f}{res['last_step']:>10}{res['drift']:>8.4f}"
          f"{res['R1']:>7.3f}{res['R2']:>7.3f}{res['kappa']:>8.3f}  {rg:>6.2f}{ree:>7.2f}{p2:>7.3f}")
    results.append(dict(run=os.path.basename(r), L=L, **res, Rg=rg, Ree=ree, P2=p2))

if results:
    ks = [x['kappa'] for x in results]
    print(f"\nκ: {'  '.join(f'{k:.3f}' for k in ks)}  mean={np.mean(ks):.3f} ± {np.std(ks, ddof=1):.3f} (n={len(ks)})")
    print(f"Rg: mean={np.mean([x['Rg'] for x in results]):.3f}  端距: mean={np.mean([x['Ree'] for x in results]):.3f}  P2: mean={np.mean([x['P2'] for x in results]):.3f}")
